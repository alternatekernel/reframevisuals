import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cx } from "../../utils/theme"

const buttonVariants = cva(
  "inline-flex cursor-pointer items-center justify-center whitespace-nowrap rounded-full text-sm font-medium ring-offset-background transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black/20 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "border border-transparent bg-[var(--color-text-primary)] text-white shadow-[0_8px_24px_rgba(0,0,0,0.10)] hover:bg-black",
        brand: "border border-transparent bg-brand text-white shadow-[0_8px_24px_rgba(0,0,0,0.10)] hover:bg-brand-hover",
        brandWhite: "border border-brand bg-white text-brand hover:bg-brand hover:text-white transition-colors duration-200",
        white: "border border-black/10 bg-white text-[var(--color-text-primary)] hover:border-black/20 hover:bg-[var(--color-bg-secondary)]",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-black/10 bg-white text-[var(--color-text-primary)] hover:border-black/20 hover:bg-[var(--color-bg-secondary)]",
        secondary: "border border-black/10 bg-white text-[var(--color-text-primary)] hover:border-black/20 hover:bg-[var(--color-bg-secondary)]",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-12 px-6 py-2",
        compact: "px-5 py-3",
        sm: "h-9 rounded-full px-3",
        lg: "h-11 rounded-full px-8",
        icon: "h-10 w-10",
        h10: "h-10 px-5 text-[14px]",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cx(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  },
)
Button.displayName = "Button"

export { Button, buttonVariants }
